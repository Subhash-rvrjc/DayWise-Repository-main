package com.example.model;
public class Student {
    private String name;
    private String email;
    private int courseId;
	public String getCourseId() {
		return null;
	}
	public String getName() {
		return null;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setCourseId(int courseId) {
		this.courseId = courseId;
	}
}